# Installation Guide - Session Tracker v1.2.0

This guide provides detailed installation instructions for Session Tracker on various platforms.

## Table of Contents
- [System Requirements](#system-requirements)
- [Linux Installation](#linux-installation)
- [Windows Installation](#windows-installation)
- [macOS Installation](#macos-installation)
- [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements
- **Python**: 3.8 or higher
- **RAM**: 256 MB
- **Disk Space**: 50 MB
- **Display**: 1024x768 or higher

### Software Dependencies
- PyQt6 (GUI framework)
- PyQt6-Multimedia (sound alerts)
- ReportLab (PDF generation)
- PyQt6-Charts (optional, for charts)

---

## Linux Installation

### Ubuntu/Debian-based Systems

#### Step 1: Update System
```bash
sudo apt update
sudo apt upgrade
```

#### Step 2: Install Python and pip
```bash
sudo apt install python3 python3-pip
```

#### Step 3: Install System Dependencies (Optional)
For sound support:
```bash
sudo apt install python3-pyqt6.qtmultimedia
sudo apt install libqt6multimedia6
```

#### Step 4: Download Session Tracker
```bash
cd ~/Downloads
# Extract the release archive
unzip session-tracker-v1.2.0.zip
cd session-tracker-v1.2.0
```

#### Step 5: Install Python Dependencies
```bash
pip3 install -r requirements.txt
```

Or install individually:
```bash
pip3 install PyQt6
pip3 install PyQt6-Charts
pip3 install PyQt6-Multimedia
pip3 install reportlab
```

#### Step 6: Make Executable (Optional)
```bash
chmod +x session_tracker.py
```

#### Step 7: Run Application
```bash
python3 session_tracker.py
# or if made executable:
./session_tracker.py
```

### Arch Linux

```bash
sudo pacman -S python python-pip
pip install -r requirements.txt
python session_tracker.py
```

### Fedora/RHEL-based Systems

```bash
sudo dnf install python3 python3-pip
pip3 install -r requirements.txt
python3 session_tracker.py
```

---

## Windows Installation

### Step 1: Install Python

1. Download Python from [python.org](https://www.python.org/downloads/)
2. Run the installer
3. **Important**: Check "Add Python to PATH" during installation
4. Click "Install Now"

### Step 2: Verify Python Installation

Open Command Prompt and run:
```cmd
python --version
pip --version
```

### Step 3: Download Session Tracker

1. Download the release ZIP file
2. Extract to a folder (e.g., `C:\SessionTracker`)

### Step 4: Install Dependencies

Open Command Prompt in the SessionTracker folder:
```cmd
cd C:\SessionTracker
pip install -r requirements.txt
```

### Step 5: Run Application

```cmd
python session_tracker.py
```

### Optional: Create Desktop Shortcut

1. Right-click on `session_tracker.py`
2. Select "Create shortcut"
3. Edit shortcut properties:
   - Target: `C:\Python3X\python.exe C:\SessionTracker\session_tracker.py`
   - Start in: `C:\SessionTracker`
   - Icon: Choose from icons folder

---

## macOS Installation

### Step 1: Install Homebrew (if not installed)

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### Step 2: Install Python

```bash
brew install python
```

### Step 3: Download Session Tracker

```bash
cd ~/Downloads
# Extract the release archive
unzip session-tracker-v1.2.0.zip
cd session-tracker-v1.2.0
```

### Step 4: Install Dependencies

```bash
pip3 install -r requirements.txt
```

### Step 5: Run Application

```bash
python3 session_tracker.py
```

### Optional: Create Application Bundle

Create a simple AppleScript application:
1. Open Script Editor
2. Paste:
```applescript
do shell script "cd ~/Downloads/session-tracker-v1.2.0 && python3 session_tracker.py"
```
3. Save as Application

---

## Virtual Environment Installation (Recommended)

Using a virtual environment keeps dependencies isolated.

### Linux/macOS

```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run application
python session_tracker.py

# Deactivate when done
deactivate
```

### Windows

```cmd
# Create virtual environment
python -m venv venv

# Activate virtual environment
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run application
python session_tracker.py

# Deactivate when done
deactivate
```

---

## Troubleshooting

### "PyQt6 not found" Error

**Solution:**
```bash
pip install --upgrade PyQt6
```

### Charts Tab Not Appearing

**Cause**: PyQt6-Charts not installed

**Solution:**
```bash
pip install PyQt6-Charts
```

### Sound Alerts Not Working

**Linux Solution:**
```bash
# Check if sound file exists
ls /usr/share/sounds/sound-icons/percussion-10.wav

# Install sound files if missing
sudo apt install sound-theme-freedesktop
```

**Windows/macOS**: Application will fall back to system beep.

### "Permission Denied" Error (Linux/macOS)

**Solution:**
```bash
chmod +x session_tracker.py
```

### Import Error: "No module named 'reportlab'"

**Solution:**
```bash
pip install reportlab
```

### Qt Platform Plugin Error

**Linux Solution:**
```bash
sudo apt install libxcb-xinerama0 libxcb-cursor0
```

### High DPI Display Issues

Set environment variable before running:

**Linux/macOS:**
```bash
export QT_AUTO_SCREEN_SCALE_FACTOR=1
python3 session_tracker.py
```

**Windows:**
```cmd
set QT_AUTO_SCREEN_SCALE_FACTOR=1
python session_tracker.py
```

---

## Verifying Installation

After installation, verify all features work:

1. **Start Application**: Should open without errors
2. **Start Session**: Create a test session
3. **Timer**: Enable timer and verify countdown works
4. **Sound**: Set 5-second timer to test sound alert
5. **Charts**: Check if Charts tab appears
6. **Calendar**: Navigate calendar view
7. **PDF Export**: Generate a test report
8. **CSV Export**: Export and re-import data

---

## Uninstallation

### Remove Application Files

Simply delete the session-tracker folder.

### Remove Python Dependencies (Optional)

```bash
pip uninstall PyQt6 PyQt6-Charts PyQt6-Multimedia reportlab
```

### Remove User Data

Session data is stored at:
- **Linux/macOS**: `~/.session_tracker/`
- **Windows**: `C:\Users\<YourName>\.session_tracker\`

Delete this folder to remove all session data.

---

## Getting Help

If you encounter issues not covered here:

1. Check the [README.md](README.md) for usage information
2. Review [CHANGELOG.md](CHANGELOG.md) for known issues
3. Open an issue on GitHub with:
   - Your OS and version
   - Python version (`python --version`)
   - Error messages (full stack trace)
   - Steps to reproduce the issue

---

**Session Tracker v1.2.0** - Installation Guide
