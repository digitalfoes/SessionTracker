#!/usr/bin/env python3
"""
Session Tracker Application
A PyQt6 application with QtCharts for tracking desktop sessions

Version: 1.2.0
Author: David Foucher
"""

import sys
import json
import datetime
from pathlib import Path
from typing import List, Dict, Any
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib import colors
from PyQt6.QtGui import QPainter
from PyQt6.QtCore import Qt, QTimer, QDateTime, pyqtSignal, QSettings
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QPushButton, QLabel, QTableWidget,
    QTableWidgetItem, QHeaderView, QTabWidget,
    QMessageBox, QSystemTrayIcon, QMenu, QFileDialog,
    QCheckBox, QLineEdit, QStyledItemDelegate, QTextEdit,
    QProgressBar, QSpinBox, QDialog, QDialogButtonBox, QFormLayout,
    QCalendarWidget, QTextBrowser, QGroupBox
)
from PyQt6.QtGui import QAction, QIcon, QPixmap, QPainter as QGuiPainter, QColor, QPen, QBrush, QFont, QTextCharFormat, QPalette, QKeySequence, QShortcut
from PyQt6.QtCore import QDate, QUrl
from PyQt6.QtMultimedia import QSoundEffect

# Import QtCharts - this is the critical import
try:
    from PyQt6.QtCharts import (
        QChart, QChartView, QPieSeries, QBarSeries, 
        QBarSet, QValueAxis, QBarCategoryAxis
    )
    CHARTS_AVAILABLE = True
except ImportError as e:
    print(f"Warning: QtCharts not available: {e}")
    CHARTS_AVAILABLE = False
    # Create dummy classes to prevent errors
    class QChart:
        pass
    class QChartView:
        def __init__(self, *args, **kwargs):
            super().__init__()


class MultiLineDelegate(QStyledItemDelegate):
    """Custom delegate for multi-line text editing in table cells"""

    def createEditor(self, parent, option, index):
        """Create a QTextEdit for editing"""
        editor = QTextEdit(parent)
        editor.setTabChangesFocus(True)
        editor.setAcceptRichText(False)
        return editor

    def setEditorData(self, editor, index):
        """Load data into the editor"""
        text = index.model().data(index, Qt.ItemDataRole.EditRole)
        editor.setPlainText(str(text) if text else "")

    def setModelData(self, editor, model, index):
        """Save data from the editor to the model"""
        text = editor.toPlainText()
        model.setData(index, text, Qt.ItemDataRole.EditRole)

    def sizeHint(self, option, index):
        """Provide size hint for the cell"""
        # Get the original size hint
        size = super().sizeHint(option, index)
        # Make the cell taller to accommodate multiple lines
        size.setHeight(max(size.height(), 60))  # Minimum 60 pixels tall
        return size


class SessionData:
    """Manages session tracking data"""

    def __init__(self):
        self.data_file = Path.home() / ".session_tracker" / "sessions.json"
        self.goals_file = Path.home() / ".session_tracker" / "goals.json"
        self.data_file.parent.mkdir(exist_ok=True)
        self.sessions = self.load_sessions()
        self.goals = self.load_goals()
        self.current_session = None
        self.session_start = None
        self.is_paused = False
        self.pause_start = None
        self.total_pause_time = 0
        self.session_duration_limit = None  # In seconds, None = unlimited
        self.session_timer_enabled = False

    def generate_session_id(self, start_time: datetime.datetime) -> str:
        """Generate a unique session ID in format YYYYMMDD-NNN"""
        date_prefix = start_time.strftime("%Y%m%d")

        # Count existing sessions with same date prefix
        existing_count = sum(1 for s in self.sessions
                           if str(s.get("id", "")).startswith(date_prefix))

        # Generate counter (001, 002, etc.)
        counter = existing_count + 1

        return f"{date_prefix}-{counter:03d}"
    
    def load_goals(self) -> Dict[str, int]:
        """Load goals from file"""
        if self.goals_file.exists():
            try:
                with open(self.goals_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                pass
        return {"daily_goal": 28800, "weekly_goal": 144000}  # Default: 8h/day, 40h/week

    def save_goals(self):
        """Save goals to file"""
        try:
            with open(self.goals_file, 'w') as f:
                json.dump(self.goals, f, indent=2)
        except IOError as e:
            raise RuntimeError(f"Failed to save goals: {e}")

    def get_today_time(self) -> int:
        """Get total active time for today in seconds"""
        today = datetime.datetime.now().date()
        total = 0
        for session in self.sessions:
            if "start" in session:
                try:
                    start_dt = datetime.datetime.fromisoformat(session["start"])
                    if start_dt.date() == today:
                        total += session.get("active_time", session.get("duration", 0))
                except (ValueError, AttributeError):
                    continue
        # Add current session if active
        if self.current_session and self.session_start:
            elapsed = (datetime.datetime.now() - self.session_start).seconds
            active_time = elapsed - self.total_pause_time
            if self.is_paused and self.pause_start:
                active_time -= (datetime.datetime.now() - self.pause_start).seconds
            total += max(0, active_time)
        return total

    def get_week_time(self) -> int:
        """Get total active time for current week in seconds"""
        today = datetime.datetime.now().date()
        week_start = today - datetime.timedelta(days=today.weekday())  # Monday
        total = 0
        for session in self.sessions:
            if "start" in session:
                try:
                    start_dt = datetime.datetime.fromisoformat(session["start"])
                    if week_start <= start_dt.date() <= today:
                        total += session.get("active_time", session.get("duration", 0))
                except (ValueError, AttributeError):
                    continue
        # Add current session if active
        if self.current_session and self.session_start:
            elapsed = (datetime.datetime.now() - self.session_start).seconds
            active_time = elapsed - self.total_pause_time
            if self.is_paused and self.pause_start:
                active_time -= (datetime.datetime.now() - self.pause_start).seconds
            total += max(0, active_time)
        return total

    def load_sessions(self) -> List[Dict[str, Any]]:
        """Load sessions from file"""
        if self.data_file.exists():
            try:
                with open(self.data_file, 'r') as f:
                    data = json.load(f)
                    # Ensure all entries have ID and notes for backward compatibility
                    for entry in data:
                        # Migrate old "comments" field to "notes"
                        if "comments" in entry and "notes" not in entry:
                            entry["notes"] = entry.pop("comments")
                        if "notes" not in entry:
                            entry["notes"] = ""

                        # Convert old numeric IDs to new format
                        if "id" not in entry or isinstance(entry.get("id"), int):
                            # Generate new ID from start time if available
                            if "start" in entry:
                                try:
                                    start_dt = datetime.datetime.fromisoformat(entry["start"])
                                    # Temporarily add to sessions for counting
                                    temp_sessions = self.sessions if hasattr(self, 'sessions') else []
                                    date_prefix = start_dt.strftime("%Y%m%d")
                                    existing_count = sum(1 for s in temp_sessions
                                                       if str(s.get("id", "")).startswith(date_prefix))
                                    counter = existing_count + 1
                                    entry["id"] = f"{date_prefix}-{counter:03d}"
                                except (ValueError, AttributeError):
                                    # Fallback: use current date with counter
                                    date_prefix = datetime.datetime.now().strftime("%Y%m%d")
                                    entry["id"] = f"{date_prefix}-{len(data):03d}"
                    return data
            except (json.JSONDecodeError, IOError) as e:
                print(f"Warning: Failed to load sessions: {e}")
                return []
        return []
    
    def save_sessions(self):
        """Save sessions to file with backup"""
        try:
            backup_file = self.data_file.with_suffix('.backup')
            if self.data_file.exists():
                self.data_file.rename(backup_file)  # Create backup
            with open(self.data_file, 'w') as f:
                json.dump(self.sessions, f, indent=2)
            if backup_file.exists():
                backup_file.unlink()  # Remove backup on success
        except (IOError, OSError) as e:
            raise RuntimeError(f"Failed to save sessions: {e}")
    
    def start_session(self, activity: str = "Work", duration_limit: int = None):
        """Start a new session with optional duration limit"""
        self.session_start = datetime.datetime.now()
        self.is_paused = False
        self.pause_start = None
        self.total_pause_time = 0
        self.session_duration_limit = duration_limit
        self.current_session = {
            "activity": activity,
            "start": self.session_start.isoformat(),
            "duration": 0,
            "active_time": 0,
            "pause_time": 0,
            "notes": "",  # Initialize notes
            "duration_limit": duration_limit  # Store the limit
        }
    
    def pause_session(self):
        """Pause the current session"""
        if self.current_session and not self.is_paused:
            self.is_paused = True
            self.pause_start = datetime.datetime.now()

    def resume_session(self):
        """Resume the paused session"""
        if self.current_session and self.is_paused and self.pause_start:
            pause_duration = (datetime.datetime.now() - self.pause_start).seconds
            self.total_pause_time += pause_duration
            self.is_paused = False
            self.pause_start = None

    def end_session(self):
        """End current session"""
        if self.current_session and self.session_start:
            # If paused, add current pause time
            if self.is_paused and self.pause_start:
                pause_duration = (datetime.datetime.now() - self.pause_start).seconds
                self.total_pause_time += pause_duration

            total_duration = (datetime.datetime.now() - self.session_start).seconds
            active_time = total_duration - self.total_pause_time

            self.current_session["end"] = datetime.datetime.now().isoformat()
            self.current_session["duration"] = total_duration
            self.current_session["active_time"] = active_time
            self.current_session["pause_time"] = self.total_pause_time

            # Generate hybrid date-counter ID
            self.current_session["id"] = self.generate_session_id(self.session_start)
            self.sessions.append(self.current_session)
            self.save_sessions()
            self.current_session = None
            self.session_start = None
            self.is_paused = False
            self.pause_start = None
            self.total_pause_time = 0
    
    def delete_entries(self, entry_ids: List[str]):
        """Delete multiple session entries by IDs.

        Args:
            entry_ids (List[str]): List of unique IDs to delete.

        Raises:
            ValueError: If any entry is not found.
            RuntimeError: If a save error occurs.
        """
        deleted_count = 0
        for entry_id in entry_ids:
            entry_found = False
            for i, session in enumerate(self.sessions):
                if str(session.get("id")) == str(entry_id):
                    del self.sessions[i]
                    entry_found = True
                    deleted_count += 1
                    break
            if not entry_found:
                raise ValueError(f"Entry with ID {entry_id} not found.")

        if deleted_count > 0:
            self.save_sessions()
        else:
            raise ValueError("No entries were deleted.")
    
    def edit_entry(self, entry_id: str, updates: Dict[str, Any]):
        """Edit an existing session entry.

        Args:
            entry_id (str): The ID of the entry to edit.
            updates (Dict[str, Any]): Key-value pairs to update (e.g., {'activity': 'New Activity', 'comments': 'Note'}).

        Raises:
            ValueError: If the entry is not found.
            RuntimeError: If a save error occurs.
        """
        entry_found = False
        for session in self.sessions:
            if str(session.get("id")) == str(entry_id):
                for key, value in updates.items():
                    if key in session or key == "notes":  # Allow notes to be added
                        session[key] = value
                entry_found = True
                break

        if not entry_found:
            raise ValueError(f"Entry with ID {entry_id} not found.")

        self.save_sessions()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Calculate statistics from sessions"""
        if not self.sessions:
            return {
                "total_sessions": 0,
                "total_time": 0,
                "average_duration": 0,
                "activities": {}
            }
        
        total_time = sum(s.get("duration", 0) for s in self.sessions)
        activities = {}
        
        for session in self.sessions:
            activity = session.get("activity", "Unknown")
            if activity not in activities:
                activities[activity] = {"count": 0, "time": 0}
            activities[activity]["count"] += 1
            activities[activity]["time"] += session.get("duration", 0)
        
        return {
            "total_sessions": len(self.sessions),
            "total_time": total_time,
            "average_duration": total_time // len(self.sessions) if self.sessions else 0,
            "activities": activities
        }

    def generate_report(self, filename: str, report_type: str = "weekly"):
        """Generate PDF report for sessions"""
        doc = SimpleDocTemplate(filename, pagesize=letter)
        story = []
        styles = getSampleStyleSheet()

        # Title
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#2196F3'),
            spaceAfter=30,
        )

        if report_type == "weekly":
            title_text = "Weekly Session Report"
            # Get sessions from the last 7 days
            cutoff_date = datetime.datetime.now() - datetime.timedelta(days=7)
        else:  # monthly
            title_text = "Monthly Session Report"
            # Get sessions from the last 30 days
            cutoff_date = datetime.datetime.now() - datetime.timedelta(days=30)

        story.append(Paragraph(title_text, title_style))
        story.append(Spacer(1, 0.2 * inch))

        # Filter sessions by date range
        filtered_sessions = []
        for session in self.sessions:
            if "start" in session:
                try:
                    start_dt = datetime.datetime.fromisoformat(session["start"])
                    if start_dt >= cutoff_date:
                        filtered_sessions.append(session)
                except (ValueError, AttributeError):
                    continue

        # Summary section
        summary_style = styles['Heading2']
        story.append(Paragraph("Summary", summary_style))
        story.append(Spacer(1, 0.1 * inch))

        total_time = sum(s.get("active_time", s.get("duration", 0)) for s in filtered_sessions)
        hours, remainder = divmod(total_time, 3600)
        minutes = remainder // 60

        summary_data = [
            ["Total Sessions:", str(len(filtered_sessions))],
            ["Total Time:", f"{hours}h {minutes}m"],
            ["Average Session:", f"{(total_time // len(filtered_sessions) // 60) if filtered_sessions else 0}m"],
        ]

        summary_table = Table(summary_data, colWidths=[2 * inch, 3 * inch])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#E3F2FD')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey)
        ]))

        story.append(summary_table)
        story.append(Spacer(1, 0.3 * inch))

        # Activity breakdown
        story.append(Paragraph("Activity Breakdown", summary_style))
        story.append(Spacer(1, 0.1 * inch))

        activities = {}
        for session in filtered_sessions:
            activity = session.get("activity", "Unknown")
            if activity not in activities:
                activities[activity] = {"count": 0, "time": 0}
            activities[activity]["count"] += 1
            activities[activity]["time"] += session.get("active_time", session.get("duration", 0))

        activity_data = [["Activity", "Sessions", "Total Time"]]
        for activity, data in activities.items():
            h, r = divmod(data["time"], 3600)
            m = r // 60
            activity_data.append([activity, str(data["count"]), f"{h}h {m}m"])

        activity_table = Table(activity_data, colWidths=[2 * inch, 1.5 * inch, 1.5 * inch])
        activity_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2196F3')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))

        story.append(activity_table)
        story.append(Spacer(1, 0.3 * inch))

        # Session details
        story.append(Paragraph("Session Details", summary_style))
        story.append(Spacer(1, 0.1 * inch))

        session_data = [["ID", "Activity", "Start", "Duration"]]
        for session in sorted(filtered_sessions, key=lambda x: x.get("start", ""), reverse=True):
            session_id = session.get("id", "N/A")
            activity = session.get("activity", "Unknown")
            start = session.get("start", "")[:16].replace("T", " ")
            duration = session.get("active_time", session.get("duration", 0))
            h, r = divmod(duration, 3600)
            m = r // 60
            session_data.append([session_id, activity, start, f"{h}h {m}m"])

        session_table = Table(session_data, colWidths=[1.5 * inch, 1.5 * inch, 2 * inch, 1 * inch])
        session_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2196F3')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
        ]))

        story.append(session_table)

        # Build PDF
        doc.build(story)


class ChartWidget(QWidget):
    """Widget for displaying charts using QtCharts"""

    def __init__(self, session_data: SessionData):
        super().__init__()
        self.session_data = session_data
        self.init_ui()

    def init_ui(self):
        """Initialize the chart UI"""
        layout = QVBoxLayout()

        if CHARTS_AVAILABLE:
            # Create tab widget for different chart types
            chart_tabs = QTabWidget()

            # Pie chart tab
            self.pie_chart_view = self.create_pie_chart()
            chart_tabs.addTab(self.pie_chart_view, "Activity Distribution")

            # Bar chart tab for time series
            self.bar_chart_view = self.create_bar_chart()
            chart_tabs.addTab(self.bar_chart_view, "Daily Trends")

            layout.addWidget(chart_tabs)

            # Add refresh button
            refresh_btn = QPushButton("Refresh Charts")
            refresh_btn.clicked.connect(self.refresh_charts)
            layout.addWidget(refresh_btn)
        else:
            # Fallback when charts are not available
            label = QLabel("Charts not available - PyQt6.QtCharts not installed")
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(label)

        self.setLayout(layout)

    def create_pie_chart(self):
        """Create a pie chart showing activity distribution"""
        stats = self.session_data.get_statistics()

        series = QPieSeries()
        for activity, data in stats["activities"].items():
            series.append(f"{activity} ({data['count']})", data["time"])

        # Customize slices
        for slice in series.slices():
            slice.setLabelVisible(True)
            slice.setLabel(f"{slice.label()}: {slice.percentage():.1f}%")

        chart = QChart()
        chart.addSeries(series)
        chart.setTitle("Activity Distribution")
        chart.setAnimationOptions(QChart.AnimationOption.SeriesAnimations)

        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.RenderHint.Antialiasing)

        return chart_view

    def create_bar_chart(self):
        """Create a bar chart showing daily session duration trends"""
        # Aggregate data by date
        daily_data = {}

        for session in self.session_data.sessions:
            if "start" in session:
                try:
                    start_dt = datetime.datetime.fromisoformat(session["start"])
                    date_key = start_dt.strftime("%Y-%m-%d")

                    if date_key not in daily_data:
                        daily_data[date_key] = 0

                    # Add active time if available, otherwise use duration
                    time_value = session.get("active_time", session.get("duration", 0))
                    daily_data[date_key] += time_value
                except (ValueError, AttributeError):
                    continue

        # Sort by date and limit to last 14 days for readability
        sorted_dates = sorted(daily_data.keys())[-14:]

        # Create bar set
        bar_set = QBarSet("Active Time (hours)")
        categories = []

        for date_str in sorted_dates:
            # Convert seconds to hours
            hours = daily_data[date_str] / 3600.0
            bar_set.append(hours)

            # Format date for display (MM-DD)
            try:
                dt = datetime.datetime.strptime(date_str, "%Y-%m-%d")
                categories.append(dt.strftime("%m-%d"))
            except ValueError:
                categories.append(date_str)

        # Create series and add bar set
        series = QBarSeries()
        series.append(bar_set)

        # Create chart
        chart = QChart()
        chart.addSeries(series)
        chart.setTitle("Daily Session Time (Last 14 Days)")
        chart.setAnimationOptions(QChart.AnimationOption.SeriesAnimations)

        # Create axes
        axis_x = QBarCategoryAxis()
        axis_x.append(categories)
        chart.addAxis(axis_x, Qt.AlignmentFlag.AlignBottom)
        series.attachAxis(axis_x)

        axis_y = QValueAxis()
        axis_y.setTitleText("Hours")
        axis_y.setLabelFormat("%.1f")
        chart.addAxis(axis_y, Qt.AlignmentFlag.AlignLeft)
        series.attachAxis(axis_y)

        # Create chart view
        chart_view = QChartView(chart)
        chart_view.setRenderHint(QPainter.RenderHint.Antialiasing)

        return chart_view

    def refresh_charts(self):
        """Refresh the charts with latest data"""
        if CHARTS_AVAILABLE:
            if hasattr(self, 'pie_chart_view'):
                new_pie_chart = self.create_pie_chart()
                layout = self.layout()
                chart_tabs = layout.itemAt(0).widget()
                if isinstance(chart_tabs, QTabWidget):
                    chart_tabs.widget(0).deleteLater()
                    chart_tabs.removeTab(0)
                    chart_tabs.insertTab(0, new_pie_chart, "Activity Distribution")
                    self.pie_chart_view = new_pie_chart

            if hasattr(self, 'bar_chart_view'):
                new_bar_chart = self.create_bar_chart()
                layout = self.layout()
                chart_tabs = layout.itemAt(0).widget()
                if isinstance(chart_tabs, QTabWidget):
                    chart_tabs.widget(1).deleteLater()
                    chart_tabs.removeTab(1)
                    chart_tabs.insertTab(1, new_bar_chart, "Daily Trends")
                    self.bar_chart_view = new_bar_chart


class CalendarWidget(QWidget):
    """Widget for displaying session calendar"""

    def __init__(self, session_data: SessionData):
        super().__init__()
        self.session_data = session_data
        self.init_ui()

    def init_ui(self):
        """Initialize the calendar UI"""
        layout = QVBoxLayout()

        # Calendar widget
        self.calendar = QCalendarWidget()
        self.calendar.setGridVisible(True)
        self.calendar.clicked.connect(self.date_clicked)
        layout.addWidget(self.calendar)

        # Details panel
        self.details_panel = QTextBrowser()
        self.details_panel.setMaximumHeight(200)
        layout.addWidget(self.details_panel)

        # Refresh button
        refresh_btn = QPushButton("Refresh Calendar")
        refresh_btn.clicked.connect(self.refresh_calendar)
        layout.addWidget(refresh_btn)

        self.setLayout(layout)

        # Initial load
        self.refresh_calendar()

    def refresh_calendar(self):
        """Refresh calendar with session data"""
        # Build activity map by date
        self.activity_by_date = {}

        for session in self.session_data.sessions:
            if "start" in session:
                try:
                    start_dt = datetime.datetime.fromisoformat(session["start"])
                    date_key = start_dt.date()

                    if date_key not in self.activity_by_date:
                        self.activity_by_date[date_key] = {
                            "total_time": 0,
                            "session_count": 0
                        }

                    self.activity_by_date[date_key]["total_time"] += session.get(
                        "active_time", session.get("duration", 0)
                    )
                    self.activity_by_date[date_key]["session_count"] += 1
                except (ValueError, AttributeError):
                    continue

        # Apply color coding to calendar
        for date_key, data in self.activity_by_date.items():
            qdate = QDate(date_key.year, date_key.month, date_key.day)
            format = QTextCharFormat()

            # Color code based on time spent
            hours = data["total_time"] / 3600.0
            if hours >= 8:
                format.setBackground(QColor(76, 175, 80, 100))  # Green - high activity
            elif hours >= 4:
                format.setBackground(QColor(255, 193, 7, 100))  # Yellow - medium activity
            else:
                format.setBackground(QColor(33, 150, 243, 100))  # Blue - low activity

            self.calendar.setDateTextFormat(qdate, format)

        # Show current date details
        self.date_clicked(self.calendar.selectedDate())

    def date_clicked(self, qdate: QDate):
        """Handle date click to show details"""
        # Convert QDate to Python date
        py_date = datetime.date(qdate.year(), qdate.month(), qdate.day())

        # Get sessions for this date
        day_sessions = []
        for session in self.session_data.sessions:
            if "start" in session:
                try:
                    start_dt = datetime.datetime.fromisoformat(session["start"])
                    if start_dt.date() == py_date:
                        day_sessions.append(session)
                except (ValueError, AttributeError):
                    continue

        # Build details HTML
        html = f"<h3>{qdate.toString('dddd, MMMM d, yyyy')}</h3>"

        if day_sessions:
            total_time = sum(
                s.get("active_time", s.get("duration", 0)) for s in day_sessions
            )
            hours, remainder = divmod(total_time, 3600)
            minutes = remainder // 60

            html += f"<p><b>Total Sessions:</b> {len(day_sessions)}</p>"
            html += f"<p><b>Total Time:</b> {hours}h {minutes}m</p>"
            html += "<hr><h4>Sessions:</h4><ul>"

            for session in day_sessions:
                activity = session.get("activity", "Unknown")
                start = session.get("start", "")
                duration = session.get("active_time", session.get("duration", 0))
                h, r = divmod(duration, 3600)
                m = r // 60
                html += f"<li><b>{activity}</b> - {h}h {m}m (started {start[11:16]})</li>"

            html += "</ul>"
        else:
            html += "<p><i>No sessions recorded for this day.</i></p>"

        self.details_panel.setHtml(html)


class GoalsDialog(QDialog):
    """Dialog for setting daily and weekly goals"""

    def __init__(self, session_data: SessionData, parent=None):
        super().__init__(parent)
        self.session_data = session_data
        self.setWindowTitle("Set Goals")
        self.setModal(True)
        self.init_ui()

    def init_ui(self):
        """Initialize the dialog UI"""
        layout = QFormLayout()

        # Daily goal (hours)
        self.daily_spinbox = QSpinBox()
        self.daily_spinbox.setRange(1, 24)
        self.daily_spinbox.setSuffix(" hours")
        daily_hours = self.session_data.goals.get("daily_goal", 28800) / 3600
        self.daily_spinbox.setValue(int(daily_hours))
        layout.addRow("Daily Goal:", self.daily_spinbox)

        # Weekly goal (hours)
        self.weekly_spinbox = QSpinBox()
        self.weekly_spinbox.setRange(1, 168)
        self.weekly_spinbox.setSuffix(" hours")
        weekly_hours = self.session_data.goals.get("weekly_goal", 144000) / 3600
        self.weekly_spinbox.setValue(int(weekly_hours))
        layout.addRow("Weekly Goal:", self.weekly_spinbox)

        # Buttons
        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

        self.setLayout(layout)

    def get_goals(self) -> Dict[str, int]:
        """Get the goal values in seconds"""
        return {
            "daily_goal": self.daily_spinbox.value() * 3600,
            "weekly_goal": self.weekly_spinbox.value() * 3600
        }


class SessionTrackerWindow(QMainWindow):
    """Main application window"""

    def __init__(self):
        super().__init__()
        self.session_data = SessionData()
        self.settings = QSettings("DavidFoucher", "SessionTracker")
        self.use_12hour_format = self.settings.value("use_12hour_format", True, type=bool)
        self.minimize_to_tray = self.settings.value("minimize_to_tray", True, type=bool)
        self.close_to_tray = self.settings.value("close_to_tray", False, type=bool)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.setInterval(50)  # Update every 50ms for smooth countdown

        # Setup sound effect for timer expiration
        self.alert_sound = QSoundEffect()
        # Try WAV file first (better compatibility)
        sound_path = "/usr/share/sounds/sound-icons/percussion-10.wav"
        if Path(sound_path).exists():
            self.alert_sound.setSource(QUrl.fromLocalFile(sound_path))
            self.alert_sound.setVolume(1.0)
            self.alert_sound.setLoopCount(3)  # Play 3 times for emphasis

        self.init_tray()
        self.init_ui()
    
    def create_tray_icon(self, active=False):
        """Create a stylized tray icon"""
        size = 64
        pixmap = QPixmap(size, size)
        pixmap.fill(Qt.GlobalColor.transparent)

        painter = QGuiPainter(pixmap)
        painter.setRenderHint(QGuiPainter.RenderHint.Antialiasing)

        # Draw circular background
        if active:
            # Green gradient for active session
            gradient_color = QColor(76, 175, 80)  # Material Green
            border_color = QColor(56, 142, 60)
        else:
            # Blue gradient for inactive
            gradient_color = QColor(33, 150, 243)  # Material Blue
            border_color = QColor(25, 118, 210)

        painter.setBrush(QBrush(gradient_color))
        painter.setPen(QPen(border_color, 2))
        painter.drawEllipse(4, 4, size - 8, size - 8)

        # Draw clock face
        painter.setPen(QPen(QColor(255, 255, 255), 2))
        center_x = size // 2
        center_y = size // 2

        # Draw clock hands
        if active:
            # Moving clock hand for active session
            painter.drawLine(center_x, center_y, center_x, center_y - 15)  # Hour hand
            painter.drawLine(center_x, center_y, center_x + 12, center_y - 8)  # Minute hand
        else:
            # Static clock hand for inactive
            painter.drawLine(center_x, center_y, center_x, center_y - 15)  # Hour hand
            painter.drawLine(center_x, center_y, center_x + 10, center_y)  # Minute hand

        # Draw center dot
        painter.setBrush(QBrush(QColor(255, 255, 255)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(center_x - 3, center_y - 3, 6, 6)

        painter.end()
        return QIcon(pixmap)

    def init_tray(self):
        """Initialize system tray icon and menu"""
        # Create tray icon
        self.tray_icon = QSystemTrayIcon(self)

        # Set initial icon
        self.tray_icon.setIcon(self.create_tray_icon(active=False))
        self.tray_icon.setToolTip("Session Tracker - No active session")

        # Create tray menu
        tray_menu = QMenu()

        # Start/Stop actions
        self.tray_start_action = QAction("Start Session", self)
        self.tray_start_action.triggered.connect(self.start_session)
        tray_menu.addAction(self.tray_start_action)

        self.tray_stop_action = QAction("Stop Session", self)
        self.tray_stop_action.triggered.connect(self.stop_session)
        self.tray_stop_action.setEnabled(False)
        tray_menu.addAction(self.tray_stop_action)

        tray_menu.addSeparator()

        # Show/Hide window action
        show_action = QAction("Show Window", self)
        show_action.triggered.connect(self.show_window)
        tray_menu.addAction(show_action)

        tray_menu.addSeparator()

        # Exit action
        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.quit_application)
        tray_menu.addAction(exit_action)

        self.tray_icon.setContextMenu(tray_menu)

        # Connect double-click to show window
        self.tray_icon.activated.connect(self.tray_icon_activated)

        # Show the tray icon
        self.tray_icon.show()

    def init_ui(self):
        """Initialize the user interface"""
        self.setWindowTitle("Session Tracker v1.1.0")
        self.setGeometry(100, 100, 1100, 600)
        
        # Central widget and main layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Header with status
        header_layout = QHBoxLayout()
        self.status_label = QLabel("No active session")
        self.status_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        self.timer_label = QLabel("00:00:00")
        self.timer_label.setStyleSheet("font-size: 14px;")
        header_layout.addWidget(self.status_label)
        header_layout.addStretch()
        header_layout.addWidget(self.timer_label)
        main_layout.addLayout(header_layout)

        # Visual countdown display (centered, black background, white text)
        countdown_layout = QHBoxLayout()
        countdown_layout.addStretch()

        self.countdown_display = QLabel("--:--:--.---")
        self.countdown_display.setStyleSheet("""
            font-size: 18px;
            font-weight: 500;
            font-family: 'Courier New', monospace;
            color: white;
            padding: 6px 12px;
            border: 1px solid #424242;
            border-radius: 4px;
            background-color: black;
        """)
        self.countdown_display.setVisible(False)
        countdown_layout.addWidget(self.countdown_display)

        countdown_layout.addStretch()
        main_layout.addLayout(countdown_layout)

        # Timer configuration
        timer_group = QGroupBox("Session Timer (Optional)")
        timer_group.setCheckable(True)
        timer_group.setChecked(False)
        timer_group.toggled.connect(self.toggle_timer_group)
        timer_layout = QHBoxLayout()

        timer_layout.addWidget(QLabel("Duration:"))

        self.timer_hours = QSpinBox()
        self.timer_hours.setRange(0, 23)
        self.timer_hours.setValue(0)
        self.timer_hours.setSuffix(" h")
        timer_layout.addWidget(self.timer_hours)

        self.timer_minutes = QSpinBox()
        self.timer_minutes.setRange(0, 59)
        self.timer_minutes.setValue(1)
        self.timer_minutes.setSuffix(" m")
        timer_layout.addWidget(self.timer_minutes)

        self.timer_seconds = QSpinBox()
        self.timer_seconds.setRange(0, 59)
        self.timer_seconds.setValue(0)
        self.timer_seconds.setSuffix(" s")
        timer_layout.addWidget(self.timer_seconds)

        timer_layout.addStretch()
        timer_group.setLayout(timer_layout)
        main_layout.addWidget(timer_group)

        # Control buttons
        button_layout = QHBoxLayout()

        self.start_btn = QPushButton("Start Session")
        self.start_btn.setIcon(QIcon("icons/play-circle.svg"))
        self.start_btn.setIconSize(self.start_btn.sizeHint() * 0.6)
        self.start_btn.clicked.connect(self.start_session)

        self.pause_btn = QPushButton("Pause")
        self.pause_btn.clicked.connect(self.toggle_pause)
        self.pause_btn.setEnabled(False)

        self.stop_btn = QPushButton("Stop Session")
        self.stop_btn.setIcon(QIcon("icons/stop-circle.svg"))
        self.stop_btn.setIconSize(self.stop_btn.sizeHint() * 0.6)
        self.stop_btn.clicked.connect(self.stop_session)
        self.stop_btn.setEnabled(False)

        button_layout.addWidget(self.start_btn)
        button_layout.addWidget(self.pause_btn)
        button_layout.addWidget(self.stop_btn)
        button_layout.addStretch()

        # Add delete button
        self.delete_btn = QPushButton("Delete Selected")
        self.delete_btn.setIcon(QIcon("icons/trash.svg"))
        self.delete_btn.setIconSize(self.delete_btn.sizeHint() * 0.6)
        self.delete_btn.clicked.connect(self.delete_selected_entry)
        self.delete_btn.setStyleSheet("background-color: #d9534f; color: white;")
        button_layout.addWidget(self.delete_btn)

        main_layout.addLayout(button_layout)

        # Search/filter bar
        search_layout = QHBoxLayout()
        search_label = QLabel("Search:")
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by ID, activity, or notes...")
        self.search_input.textChanged.connect(self.filter_sessions)
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.search_input)

        main_layout.addLayout(search_layout)

        # Tab widget for different views
        self.tab_widget = QTabWidget()

        # Sessions tab
        self.sessions_table = self.create_sessions_table()
        self.tab_widget.addTab(self.sessions_table, QIcon("icons/list.svg"), "Sessions")

        # Statistics tab
        self.stats_widget = self.create_stats_widget()
        self.tab_widget.addTab(self.stats_widget, QIcon("icons/bar-chart.svg"), "Statistics")

        # Calendar tab
        self.calendar_widget = CalendarWidget(self.session_data)
        self.tab_widget.addTab(self.calendar_widget, "Calendar")

        # Charts tab (if available)
        if CHARTS_AVAILABLE:
            self.chart_widget = ChartWidget(self.session_data)
            self.tab_widget.addTab(self.chart_widget, QIcon("icons/pie-chart.svg"), "Charts")
        
        main_layout.addWidget(self.tab_widget)
        
        # Create menu bar
        self.create_menu_bar()
        
        # Load initial data
        self.refresh_sessions_table()

        # Setup keyboard shortcuts
        self.setup_shortcuts()

    def setup_shortcuts(self):
        """Setup keyboard shortcuts"""
        # Start session: Ctrl+Shift+S
        start_shortcut = QShortcut(QKeySequence("Ctrl+Shift+S"), self)
        start_shortcut.activated.connect(self.start_session)

        # Stop session: Ctrl+Shift+T
        stop_shortcut = QShortcut(QKeySequence("Ctrl+Shift+T"), self)
        stop_shortcut.activated.connect(self.stop_session)

        # Pause/Resume: Ctrl+Shift+P
        pause_shortcut = QShortcut(QKeySequence("Ctrl+Shift+P"), self)
        pause_shortcut.activated.connect(self.toggle_pause)

        # Quick export: Ctrl+Shift+E
        export_shortcut = QShortcut(QKeySequence("Ctrl+Shift+E"), self)
        export_shortcut.activated.connect(self.export_data)

    def create_menu_bar(self):
        """Create the application menu bar"""
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("File")

        import_action = QAction("Import Data", self)
        import_action.triggered.connect(self.import_data)
        file_menu.addAction(import_action)

        export_action = QAction("Export Data", self)
        export_action.triggered.connect(self.export_data)
        file_menu.addAction(export_action)

        file_menu.addSeparator()

        # Report generation submenu
        report_menu = file_menu.addMenu("Generate Report")

        weekly_report_action = QAction("Weekly Report (PDF)", self)
        weekly_report_action.triggered.connect(lambda: self.generate_report("weekly"))
        report_menu.addAction(weekly_report_action)

        monthly_report_action = QAction("Monthly Report (PDF)", self)
        monthly_report_action.triggered.connect(lambda: self.generate_report("monthly"))
        report_menu.addAction(monthly_report_action)

        file_menu.addSeparator()

        exit_action = QAction("Exit", self)
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # Edit menu
        edit_menu = menubar.addMenu("Edit")

        delete_action = QAction("Delete Selected Entry", self)
        delete_action.setShortcut("Delete")
        delete_action.triggered.connect(self.delete_selected_entry)
        edit_menu.addAction(delete_action)

        # Options menu
        options_menu = menubar.addMenu("Options")

        # Time format option
        self.time_format_action = QAction("Use 12-hour time format (AM/PM)", self)
        self.time_format_action.setCheckable(True)
        self.time_format_action.setChecked(self.use_12hour_format)
        self.time_format_action.triggered.connect(self.toggle_time_format_menu)
        options_menu.addAction(self.time_format_action)

        options_menu.addSeparator()

        # Minimize to tray option
        self.minimize_to_tray_action = QAction("Minimize to system tray", self)
        self.minimize_to_tray_action.setCheckable(True)
        self.minimize_to_tray_action.setChecked(self.minimize_to_tray)
        self.minimize_to_tray_action.triggered.connect(self.toggle_minimize_to_tray_menu)
        options_menu.addAction(self.minimize_to_tray_action)

        # Close to tray option
        self.close_to_tray_action = QAction("Close to tray instead of exit", self)
        self.close_to_tray_action.setCheckable(True)
        self.close_to_tray_action.setChecked(self.close_to_tray)
        self.close_to_tray_action.triggered.connect(self.toggle_close_to_tray_menu)
        options_menu.addAction(self.close_to_tray_action)

        # About menu
        about_menu = menubar.addMenu("About")

        about_action = QAction("About Session Tracker", self)
        about_action.triggered.connect(self.show_about)
        about_menu.addAction(about_action)
    
    def create_sessions_table(self) -> QTableWidget:
        """Create the sessions table widget"""
        table = QTableWidget()
        table.setColumnCount(6)
        table.setHorizontalHeaderLabels(["ID", "Activity", "Start Time", "End Time", "Duration", "Notes"])
        header = table.horizontalHeader()

        # Make columns resizable by the user
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)

        # Set minimum column widths
        header.setMinimumSectionSize(80)
        table.setColumnWidth(0, 120)  # ID
        table.setColumnWidth(1, 150)  # Activity
        table.setColumnWidth(2, 180)  # Start Time
        table.setColumnWidth(3, 180)  # End Time
        table.setColumnWidth(4, 100)  # Duration
        table.setColumnWidth(5, 250)  # Notes (wider for multi-line content)

        # Enable last column to stretch to fill remaining space
        header.setStretchLastSection(True)

        table.setEditTriggers(QTableWidget.EditTrigger.DoubleClicked | QTableWidget.EditTrigger.EditKeyPressed)
        table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        table.setSelectionMode(QTableWidget.SelectionMode.ExtendedSelection)

        # Set custom delegate for Notes column (column 5) to enable multi-line editing
        notes_delegate = MultiLineDelegate(table)
        table.setItemDelegateForColumn(5, notes_delegate)

        # Enable word wrap for better multi-line display
        table.setWordWrap(True)

        # Allow rows to resize to content
        table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)

        # Connect cell changed signal to save edits
        table.cellChanged.connect(self.on_cell_changed)

        return table
    
    def create_stats_widget(self) -> QWidget:
        """Create the statistics widget"""
        widget = QWidget()
        layout = QVBoxLayout()
        
        self.stats_label = QLabel()
        self.stats_label.setStyleSheet("font-size: 12px; padding: 10px;")
        self.update_statistics()
        
        layout.addWidget(self.stats_label)
        widget.setLayout(layout)
        return widget
    
    def format_datetime(self, iso_string: str) -> str:
        """Format datetime string based on user preference"""
        try:
            dt = datetime.datetime.fromisoformat(iso_string)
            if self.use_12hour_format:
                return dt.strftime("%Y-%m-%d %I:%M:%S %p")
            else:
                return dt.strftime("%Y-%m-%d %H:%M:%S")
        except (ValueError, AttributeError):
            return iso_string
    
    def toggle_time_format_menu(self, checked):
        """Toggle between 12-hour and 24-hour time format from menu"""
        self.use_12hour_format = checked
        self.settings.setValue("use_12hour_format", self.use_12hour_format)
        self.refresh_sessions_table()

    def toggle_minimize_to_tray_menu(self, checked):
        """Toggle minimize to tray setting from menu"""
        self.minimize_to_tray = checked
        self.settings.setValue("minimize_to_tray", self.minimize_to_tray)

    def toggle_close_to_tray_menu(self, checked):
        """Toggle close to tray setting from menu"""
        self.close_to_tray = checked
        self.settings.setValue("close_to_tray", self.close_to_tray)

    def tray_icon_activated(self, reason):
        """Handle tray icon activation (click/double-click)"""
        # Respond to both single-click (Trigger) and double-click for easier access
        if reason in (QSystemTrayIcon.ActivationReason.Trigger,
                      QSystemTrayIcon.ActivationReason.DoubleClick):
            self.show_window()

    def show_window(self):
        """Show and activate the main window"""
        # Clear minimized state and restore to normal
        if self.isMinimized():
            self.setWindowState(Qt.WindowState.WindowNoState)

        # Show the window normally (not minimized)
        self.showNormal()

        # Activate and bring to front
        self.activateWindow()
        self.raise_()

        # Platform-specific: ensure focus (helps on X11/Linux)
        self.setFocus()

    def quit_application(self):
        """Quit the application completely"""
        if self.session_data.current_session:
            reply = QMessageBox.question(
                self,
                "Active Session",
                "There is an active session. Do you want to stop it before exiting?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )

            if reply == QMessageBox.StandardButton.Yes:
                self.stop_session()

        QApplication.quit()
    
    def on_cell_changed(self, row: int, column: int):
        """Handle cell editing in the table"""
        # Temporarily disconnect to avoid recursive calls
        self.sessions_table.cellChanged.disconnect(self.on_cell_changed)

        try:
            # Get the entry ID from the first column
            id_item = self.sessions_table.item(row, 0)
            if id_item is None:
                return

            entry_id = id_item.text()  # Now a string (e.g., "20251003-001")

            # Determine what was edited and update accordingly
            updates = {}

            if column == 1:  # Activity
                item = self.sessions_table.item(row, column)
                if item:
                    updates["activity"] = item.text()
            elif column == 5:  # Notes
                item = self.sessions_table.item(row, column)
                if item:
                    updates["notes"] = item.text()

            # Save changes if any updates were made
            if updates:
                self.session_data.edit_entry(entry_id, updates)

        except (ValueError, RuntimeError) as e:
            QMessageBox.warning(self, "Edit Error", f"Failed to save changes: {e}")
        finally:
            # Reconnect the signal
            self.sessions_table.cellChanged.connect(self.on_cell_changed)
    
    def toggle_pause(self):
        """Toggle pause/resume for current session"""
        if self.session_data.is_paused:
            # Resume
            self.session_data.resume_session()
            self.pause_btn.setText("Pause")
            self.status_label.setText("Session Active")
            self.timer.start(1000)
        else:
            # Pause
            self.session_data.pause_session()
            self.pause_btn.setText("Resume")
            self.status_label.setText("Session Paused")
            self.timer.stop()

    def toggle_timer_group(self, checked):
        """Toggle timer group visibility/state"""
        # Timer group handles enable/disable automatically when checkable
        pass

    def toggle_session_timer_column(self, checked):
        """Toggle session timer column visibility/state"""
        # Session timer column handles enable/disable automatically when checkable
        pass

    def start_session(self):
        """Start a new tracking session"""
        # Get timer duration if enabled
        duration_limit = None
        timer_enabled = hasattr(self, 'timer_hours') and self.timer_hours.parent().isChecked()

        if timer_enabled:
            hours = self.timer_hours.value()
            minutes = self.timer_minutes.value()
            seconds = self.timer_seconds.value()
            duration_limit = (hours * 3600) + (minutes * 60) + seconds

            if duration_limit == 0:
                QMessageBox.warning(
                    self, "Invalid Timer",
                    "Please set a duration greater than 0 seconds."
                )
                return

        self.session_data.start_session(duration_limit=duration_limit)

        # Disable timer group during session
        if hasattr(self, 'timer_hours'):
            self.timer_hours.parent().setEnabled(False)

        self.start_btn.setEnabled(False)
        self.pause_btn.setEnabled(True)
        self.pause_btn.setText("Pause")
        self.stop_btn.setEnabled(True)

        # Update tray menu actions
        self.tray_start_action.setEnabled(False)
        self.tray_stop_action.setEnabled(True)

        # Change tray icon to active (green)
        self.tray_icon.setIcon(self.create_tray_icon(active=True))

        if duration_limit:
            hours, remainder = divmod(duration_limit, 3600)
            minutes, seconds = divmod(remainder, 60)
            if hours > 0:
                self.status_label.setText(f"Session Active (Timer: {hours}h {minutes}m {seconds}s)")
            elif minutes > 0:
                self.status_label.setText(f"Session Active (Timer: {minutes}m {seconds}s)")
            else:
                self.status_label.setText(f"Session Active (Timer: {seconds}s)")
        else:
            self.status_label.setText("Session Active")

        self.timer.start()  # Start with 50ms interval

        # Show tray notification
        if self.tray_icon.supportsMessages():
            if duration_limit:
                h, r = divmod(duration_limit, 3600)
                m, s = divmod(r, 60)
                if h > 0:
                    time_str = f"{h}h {m}m {s}s"
                elif m > 0:
                    time_str = f"{m}m {s}s"
                else:
                    time_str = f"{s}s"
                self.tray_icon.showMessage(
                    "Session Started",
                    f"Timer set for {time_str}",
                    QSystemTrayIcon.MessageIcon.Information,
                    2000
                )
            else:
                self.tray_icon.showMessage(
                    "Session Started",
                    "Tracking session has begun",
                    QSystemTrayIcon.MessageIcon.Information,
                    2000
                )
    
    def stop_session(self):
        """Stop the current tracking session"""
        # Calculate duration before ending session
        if self.session_data.session_start:
            elapsed = datetime.datetime.now() - self.session_data.session_start
            hours, remainder = divmod(elapsed.seconds, 3600)
            minutes, seconds = divmod(remainder, 60)
            duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        else:
            duration_str = "00:00:00"

        self.session_data.end_session()

        # Re-enable timer group
        if hasattr(self, 'timer_hours'):
            self.timer_hours.parent().setEnabled(True)

        self.start_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self.pause_btn.setText("Pause")
        self.stop_btn.setEnabled(False)

        # Update tray menu actions
        self.tray_start_action.setEnabled(True)
        self.tray_stop_action.setEnabled(False)

        # Change tray icon to inactive (blue)
        self.tray_icon.setIcon(self.create_tray_icon(active=False))

        self.status_label.setText("No active session")
        self.timer.stop()
        self.timer_label.setText("00:00:00")
        self.countdown_display.setVisible(False)

        # Update tray tooltip
        self.tray_icon.setToolTip("Session Tracker - No active session")

        # Show tray notification
        if self.tray_icon.supportsMessages():
            self.tray_icon.showMessage(
                "Session Stopped",
                f"Session duration: {duration_str}",
                QSystemTrayIcon.MessageIcon.Information,
                3000
            )

        self.refresh_sessions_table()
        self.update_statistics()

        # Refresh calendar
        if hasattr(self, 'calendar_widget'):
            self.calendar_widget.refresh_calendar()

        # Refresh charts if available
        if CHARTS_AVAILABLE and hasattr(self, 'chart_widget'):
            self.chart_widget.refresh_charts()

    def update_timer(self):
        """Update the timer display with millisecond precision"""
        if self.session_data.session_start:
            now = datetime.datetime.now()
            total_elapsed = now - self.session_data.session_start

            # Calculate active time (excluding pauses)
            pause_time = self.session_data.total_pause_time
            if self.session_data.is_paused and self.session_data.pause_start:
                current_pause = (now - self.session_data.pause_start).total_seconds()
                pause_time += int(current_pause)

            # Total active time in seconds with microseconds
            active_total_seconds = total_elapsed.total_seconds() - pause_time
            active_seconds = int(active_total_seconds)
            milliseconds = int((active_total_seconds - active_seconds) * 1000)

            # Check if timer is enabled and session expired
            if self.session_data.session_duration_limit:
                remaining_total = self.session_data.session_duration_limit - active_total_seconds

                if remaining_total <= 0:
                    # Timer expired!
                    self.timer_expired()
                    return

                # Show countdown with milliseconds
                remaining_seconds = int(remaining_total)
                remaining_ms = int((remaining_total - remaining_seconds) * 1000)

                hours, remainder = divmod(remaining_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)

                # Small timer display
                time_str = f"-{hours:02d}:{minutes:02d}:{seconds:02d}"
                self.timer_label.setText(time_str)
                self.timer_label.setStyleSheet("font-size: 14px; color: #FF5722;")

                # Large countdown display with milliseconds
                countdown_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}.{remaining_ms:03d}"
                self.countdown_display.setText(countdown_str)
                self.countdown_display.setVisible(True)

                # Update tray tooltip
                status = "Paused" if self.session_data.is_paused else "Active"
                self.tray_icon.setToolTip(f"Session Tracker - {status} (Timer: {time_str})")
            else:
                # Regular elapsed time display
                hours, remainder = divmod(active_seconds, 3600)
                minutes, seconds = divmod(remainder, 60)
                time_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
                self.timer_label.setText(time_str)
                self.timer_label.setStyleSheet("font-size: 14px;")

                # Hide countdown display when no timer
                self.countdown_display.setVisible(False)

                # Update tray tooltip with current session time
                status = "Paused" if self.session_data.is_paused else "Active"
                self.tray_icon.setToolTip(f"Session Tracker - {status}: {time_str}")

    def timer_expired(self):
        """Handle timer expiration"""
        self.timer.stop()

        # Play alert sound (multiple beeps)
        if self.alert_sound.source().isValid():
            self.alert_sound.play()
        else:
            # Fallback: system beep
            QApplication.beep()

        # Show alert dialog
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Icon.Warning)
        msg.setWindowTitle("Session Timer Expired")
        msg.setText("Your session timer has expired!")
        msg.setInformativeText("The session will be stopped automatically.")
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)

        # Show tray notification
        if self.tray_icon.supportsMessages():
            self.tray_icon.showMessage(
                "Timer Expired!",
                "Session timer has reached its limit",
                QSystemTrayIcon.MessageIcon.Warning,
                5000
            )

        msg.exec()

        # Auto-stop the session
        self.stop_session()

    def generate_report(self, report_type: str):
        """Generate PDF report"""
        # Suggest filename
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        default_filename = f"session_tracker_{report_type}_report_{timestamp}.pdf"

        filename, _ = QFileDialog.getSaveFileName(
            self, f"Save {report_type.capitalize()} Report",
            default_filename,
            "PDF Files (*.pdf);;All Files (*)"
        )

        if filename:
            # Ensure .pdf extension
            if not filename.lower().endswith('.pdf'):
                filename += '.pdf'

            try:
                self.session_data.generate_report(filename, report_type)
                QMessageBox.information(
                    self, "Report Generated",
                    f"{report_type.capitalize()} report generated successfully:\n{filename}"
                )
            except Exception as e:
                QMessageBox.critical(
                    self, "Report Error",
                    f"Failed to generate report: {str(e)}"
                )

    def filter_sessions(self, search_text: str = ""):
        """Filter sessions table based on search text"""
        search_text = self.search_input.text().lower() if hasattr(self, 'search_input') else ""

        for row in range(self.sessions_table.rowCount()):
            should_show = True

            # Apply text search filter
            if search_text:
                text_match = False
                # Search in ID, activity, and notes columns
                for col in [0, 1, 5]:  # ID, Activity, Notes
                    item = self.sessions_table.item(row, col)
                    if item and search_text in item.text().lower():
                        text_match = True
                        break
                should_show = text_match

            self.sessions_table.setRowHidden(row, not should_show)

    def refresh_sessions_table(self):
        """Refresh the sessions table with current data"""
        # Temporarily disconnect to avoid triggering cellChanged during refresh
        self.sessions_table.cellChanged.disconnect(self.on_cell_changed)

        sessions = self.session_data.sessions
        self.sessions_table.setRowCount(len(sessions))
        
        for row, session in enumerate(sessions):
            entry_id = session.get("id", row + 1)
            
            # ID column (not editable)
            id_item = QTableWidgetItem(str(entry_id))
            id_item.setFlags(id_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.sessions_table.setItem(row, 0, id_item)
            
            # Activity column (editable)
            self.sessions_table.setItem(row, 1, QTableWidgetItem(session.get("activity", "")))
            
            # Start time column (not editable)
            start_item = QTableWidgetItem(self.format_datetime(session.get("start", "")))
            start_item.setFlags(start_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.sessions_table.setItem(row, 2, start_item)
            
            # End time column (not editable)
            end_item = QTableWidgetItem(self.format_datetime(session.get("end", "")))
            end_item.setFlags(end_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.sessions_table.setItem(row, 3, end_item)
            
            # Duration column (not editable)
            duration = session.get("duration", 0)
            hours, remainder = divmod(duration, 3600)
            minutes, seconds = divmod(remainder, 60)
            duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            duration_item = QTableWidgetItem(duration_str)
            duration_item.setFlags(duration_item.flags() & ~Qt.ItemFlag.ItemIsEditable)
            self.sessions_table.setItem(row, 4, duration_item)
            
            # Notes column (editable)
            self.sessions_table.setItem(row, 5, QTableWidgetItem(session.get("notes", "")))
        
        # Reconnect the signal
        self.sessions_table.cellChanged.connect(self.on_cell_changed)
    
    def delete_selected_entry(self):
        """Delete selected entries from the table and database"""
        selected_rows = self.sessions_table.selectionModel().selectedRows()
        if not selected_rows:
            QMessageBox.warning(self, "No Selection", "Please select one or more entries to delete.")
            return

        entry_ids = []
        for row in selected_rows:
            entry_id = self.sessions_table.item(row.row(), 0).text()  # String ID
            entry_ids.append(entry_id)

        # Confirmation dialog
        if len(entry_ids) == 1:
            message = "Are you sure you want to delete this entry?"
        else:
            message = f"Are you sure you want to delete {len(entry_ids)} selected entries?"

        reply = QMessageBox.question(
            self, "Confirm Deletion", message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No
        )

        if reply == QMessageBox.StandardButton.Yes:
            try:
                self.session_data.delete_entries(entry_ids)
                self.refresh_sessions_table()
                self.update_statistics()
                if CHARTS_AVAILABLE and hasattr(self, 'chart_widget'):
                    self.chart_widget.refresh_charts()

                if len(entry_ids) == 1:
                    QMessageBox.information(self, "Success", "Entry deleted successfully.")
                else:
                    QMessageBox.information(self, "Success", f"{len(entry_ids)} entries deleted successfully.")
            except ValueError as e:
                QMessageBox.warning(self, "Error", str(e))
            except RuntimeError as e:
                QMessageBox.critical(self, "Database Error", str(e))
    
    def update_statistics(self):
        """Update the statistics display"""
        stats = self.session_data.get_statistics()
        
        total_hours = stats["total_time"] // 3600
        total_minutes = (stats["total_time"] % 3600) // 60
        avg_minutes = stats["average_duration"] // 60
        
        stats_text = f"""
        <h3>Session Statistics</h3>
        <p><b>Total Sessions:</b> {stats["total_sessions"]}</p>
        <p><b>Total Time:</b> {total_hours} hours, {total_minutes} minutes</p>
        <p><b>Average Duration:</b> {avg_minutes} minutes</p>
        <h4>Activities:</h4>
        """
        
        for activity, data in stats["activities"].items():
            hours = data["time"] // 3600
            minutes = (data["time"] % 3600) // 60
            stats_text += f"<p><b>{activity}:</b> {data['count']} sessions, {hours}h {minutes}m</p>"
        
        self.stats_label.setText(stats_text)
    
    def export_data(self):
        """Export session data to CSV"""
        import csv

        # Suggest a default filename with timestamp
        default_filename = f"session_tracker_export_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

        filename, _ = QFileDialog.getSaveFileName(
            self, "Export Data", default_filename, "CSV Files (*.csv);;All Files (*)"
        )

        if filename:
            # Ensure filename has .csv extension
            if not filename.lower().endswith('.csv'):
                filename += '.csv'

            with open(filename, 'w', newline='') as csvfile:
                writer = csv.DictWriter(
                    csvfile,
                    fieldnames=["id", "activity", "start", "end", "duration", "notes"]
                )
                writer.writeheader()
                writer.writerows(self.session_data.sessions)

            QMessageBox.information(self, "Export Complete", f"Data exported to:\n{filename}")

    def import_data(self):
        """Import session data from CSV"""
        import csv

        filename, _ = QFileDialog.getOpenFileName(
            self, "Import Data", "", "CSV Files (*.csv);;All Files (*)"
        )

        if not filename:
            return

        try:
            imported_count = 0
            skipped_count = 0
            errors = []

            with open(filename, 'r', newline='') as csvfile:
                reader = csv.DictReader(csvfile)

                # Validate CSV has required fields
                required_fields = ["activity", "start", "duration"]
                if not all(field in reader.fieldnames for field in required_fields):
                    QMessageBox.warning(
                        self, "Import Error",
                        f"CSV must contain columns: {', '.join(required_fields)}"
                    )
                    return

                for row_num, row in enumerate(reader, start=2):
                    try:
                        # Parse and validate the row
                        start_time = datetime.datetime.fromisoformat(row["start"])

                        # Create session entry
                        session = {
                            "activity": row.get("activity", "Imported"),
                            "start": start_time.isoformat(),
                            "end": row.get("end", ""),
                            "duration": int(row.get("duration", 0)),
                            "notes": row.get("notes", row.get("comments", ""))  # Support both
                        }

                        # Generate new ID based on start time
                        session["id"] = self.session_data.generate_session_id(start_time)

                        # Check for duplicate (same start time and activity)
                        is_duplicate = any(
                            s.get("start") == session["start"] and
                            s.get("activity") == session["activity"]
                            for s in self.session_data.sessions
                        )

                        if is_duplicate:
                            skipped_count += 1
                        else:
                            self.session_data.sessions.append(session)
                            imported_count += 1

                    except (ValueError, KeyError) as e:
                        errors.append(f"Row {row_num}: {str(e)}")

            # Save if any sessions were imported
            if imported_count > 0:
                self.session_data.save_sessions()
                self.refresh_sessions_table()
                self.update_statistics()
                if CHARTS_AVAILABLE and hasattr(self, 'chart_widget'):
                    self.chart_widget.refresh_charts()

            # Show import summary
            summary = f"Import complete!\n\n"
            summary += f"Imported: {imported_count} sessions\n"
            summary += f"Skipped (duplicates): {skipped_count} sessions\n"

            if errors:
                summary += f"\nErrors: {len(errors)}\n"
                summary += "\n".join(errors[:5])  # Show first 5 errors
                if len(errors) > 5:
                    summary += f"\n... and {len(errors) - 5} more"

            QMessageBox.information(self, "Import Summary", summary)

        except Exception as e:
            QMessageBox.critical(self, "Import Error", f"Failed to import data: {str(e)}")

    def show_about(self):
        """Show about dialog"""
        about_text = """
        <h2>Session Tracker</h2>
        <p><b>Version:</b> 1.1.0</p>
        <p><b>Author:</b> David Foucher</p>
        <p><b>Copyright:</b> © 2025 David Foucher. All rights reserved.</p>
        <hr>
        <h3>Features</h3>
        <ul>
            <li>Session timing with pause/resume functionality</li>
            <li>Hybrid session IDs (YYYYMMDD-NNN format)</li>
            <li>Multi-line notes field for detailed documentation</li>
            <li>Resizable table columns</li>
            <li>Search and filter sessions</li>
            <li>12/24-hour time format display</li>
            <li>Statistical analysis with pie and bar charts</li>
            <li>Calendar view with color-coded activity levels</li>
            <li>PDF report generation (weekly/monthly)</li>
            <li>CSV import/export</li>
            <li>System tray integration</li>
        </ul>

        <h3>Keyboard Shortcuts</h3>
        <table border="0" cellpadding="4">
            <tr><td><b>Ctrl+Shift+S</b></td><td>Start Session</td></tr>
            <tr><td><b>Ctrl+Shift+T</b></td><td>Stop Session</td></tr>
            <tr><td><b>Ctrl+Shift+P</b></td><td>Pause/Resume</td></tr>
            <tr><td><b>Ctrl+Shift+E</b></td><td>Quick Export (CSV)</td></tr>
            <tr><td><b>Delete</b></td><td>Delete Selected Entry</td></tr>
        </table>

        <h3>Session ID Format</h3>
        <p>Sessions use a hybrid ID format: <b>YYYYMMDD-NNN</b></p>
        <p>Example: <code>20251003-001</code> (First session on Oct 3, 2025)</p>
        <p>This format is human-readable, searchable by date, and never reused.</p>

        <h3>Calendar Color Coding</h3>
        <ul>
            <li><span style="color: #4CAF50;">■</span> <b>Green:</b> High activity (8+ hours)</li>
            <li><span style="color: #FFC107;">■</span> <b>Yellow:</b> Medium activity (4-8 hours)</li>
            <li><span style="color: #2196F3;">■</span> <b>Blue:</b> Low activity (&lt;4 hours)</li>
        </ul>

        <h3>Data Storage</h3>
        <p>Sessions are stored in: <code>~/.session_tracker/sessions.json</code></p>
        <p>Automatic backups are created before each save operation.</p>

        <h3>Technical Details</h3>
        <p>Built with PyQt6, QtCharts, and ReportLab for PDF generation.</p>
        """
        QMessageBox.about(self, "About Session Tracker", about_text)
    
    def changeEvent(self, event):
        """Handle window state changes (minimize)"""
        if event.type() == event.Type.WindowStateChange:
            if self.isMinimized() and self.minimize_to_tray:
                # Use QTimer.singleShot to defer hiding - avoids event handling conflicts
                QTimer.singleShot(0, self.hide_to_tray)
        super().changeEvent(event)

    def hide_to_tray(self):
        """Hide window to tray (called via deferred timer)"""
        self.hide()
        if self.tray_icon.supportsMessages():
            self.tray_icon.showMessage(
                "Session Tracker",
                "Application minimized to tray",
                QSystemTrayIcon.MessageIcon.Information,
                2000
            )

    def closeEvent(self, event):
        """Handle window close event"""
        if self.close_to_tray:
            event.ignore()
            self.hide()
            if self.tray_icon.supportsMessages():
                self.tray_icon.showMessage(
                    "Session Tracker",
                    "Application is still running in the system tray",
                    QSystemTrayIcon.MessageIcon.Information,
                    2000
                )
        else:
            if self.session_data.current_session:
                reply = QMessageBox.question(
                    self,
                    "Active Session",
                    "There is an active session. Do you want to stop it before closing?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes
                )

                if reply == QMessageBox.StandardButton.Yes:
                    self.stop_session()

            event.accept()


def main():
    """Main application entry point"""
    app = QApplication(sys.argv)
    app.setApplicationName("Session Tracker")
    app.setOrganizationName("DavidFoucher")
    
    # Set application style
    app.setStyle("Fusion")
    
    # Create and show main window
    window = SessionTrackerWindow()
    window.show()
    
    # Check if QtCharts is available
    if not CHARTS_AVAILABLE:
        QMessageBox.warning(
            window,
            "QtCharts Not Available",
            "PyQt6.QtCharts is not installed. Charts functionality will be disabled.\n"
            "Install with: pip install PyQt6-Charts",
            QMessageBox.StandardButton.Ok
        )
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
